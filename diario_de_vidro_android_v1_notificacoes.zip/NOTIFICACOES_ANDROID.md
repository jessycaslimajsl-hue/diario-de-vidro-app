# Notificações nativas — Diário de Vidro V1

A V1 agora possui uma ponte entre o protótipo HTML e o Android.

## O que foi implementado
- Canal nativo "Lembretes do Diário de Vidro".
- Permissão POST_NOTIFICATIONS no Android 13+.
- AlarmManager para agendar lembretes.
- Receiver para mostrar a notificação mesmo com o app fechado.
- Ponte JavaScript `AndroidNotifications`.
- Funções prontas no HTML:
  - `DiarioNotifications.scheduleWeight(date)`
  - `DiarioNotifications.scheduleMedication(date, nome)`
  - `DiarioNotifications.scheduleCycle(date)`
  - `DiarioNotifications.scheduleMeal(date)`
  - `DiarioNotifications.cancel(id)`

## Observação
O protótipo atual ainda não possui uma tela completa para configurar todos os horários. A infraestrutura nativa está pronta para a próxima etapa, que é conectar os horários/datas salvos no app aos lembretes.

Em alguns aparelhos Android, o sistema pode aplicar otimizações de bateria aos alarmes. Para lembretes críticos, o usuário pode precisar permitir alarmes/notificações nas configurações do aparelho.
