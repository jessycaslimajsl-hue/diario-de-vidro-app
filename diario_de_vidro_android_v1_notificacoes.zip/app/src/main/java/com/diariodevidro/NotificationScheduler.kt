package com.diariodevidro

import android.app.*
import android.content.*
import android.os.Build

object NotificationScheduler {
    private const val EXTRA_ID = "notification_id"
    private const val EXTRA_TITLE = "notification_title"
    private const val EXTRA_MESSAGE = "notification_message"

    fun schedule(context: Context, id: Int, title: String, message: String, timeMillis: Long) {
        if (timeMillis <= System.currentTimeMillis()) return

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, NotificationReceiver::class.java).apply {
            putExtra(EXTRA_ID, id)
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_MESSAGE, message)
        }

        val pending = PendingIntent.getBroadcast(
            context, id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            !alarmManager.canScheduleExactAlarms()) {
            alarmManager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP, timeMillis, pending
            )
        } else {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP, timeMillis, pending
            )
        }
    }

    fun cancel(context: Context, id: Int) {
        val intent = Intent(context, NotificationReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context, id, intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pending != null) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.cancel(pending)
            pending.cancel()
        }
    }

    internal fun id(intent: Intent) = intent.getIntExtra(EXTRA_ID, 0)
    internal fun title(intent: Intent) = intent.getStringExtra(EXTRA_TITLE) ?: "Diário de Vidro"
    internal fun message(intent: Intent) = intent.getStringExtra(EXTRA_MESSAGE)
        ?: "Hora de registrar seu diário. 🌷"
}
