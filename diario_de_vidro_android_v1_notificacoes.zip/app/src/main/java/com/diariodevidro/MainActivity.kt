package com.diariodevidro

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val notificationPermissionRequest = 9001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        NotificationHelper.createChannel(this)
        requestNotificationPermissionIfNeeded()

        webView = WebView(this)
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
        }

        webView.addJavascriptInterface(NotificationBridge(this), "AndroidNotifications")
        webView.loadUrl("file:///android_asset/index.html")
        setContentView(webView)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                notificationPermissionRequest
            )
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}

class NotificationBridge(private val context: Context) {

    @JavascriptInterface
    fun schedule(id: Int, title: String, message: String, timeMillis: Long) {
        NotificationScheduler.schedule(context, id, title, message, timeMillis)
    }

    @JavascriptInterface
    fun cancel(id: Int) {
        NotificationScheduler.cancel(context, id)
    }

    @JavascriptInterface
    fun scheduleFromJson(id: Int, json: String) {
        val obj = JSONObject(json)
        val title = obj.optString("title", "Diário de Vidro")
        val message = obj.optString("message", "Hora de registrar seu diário. 🌷")
        val time = obj.optLong("timeMillis", 0L)
        if (time > 0L) NotificationScheduler.schedule(context, id, title, message, time)
    }
}
