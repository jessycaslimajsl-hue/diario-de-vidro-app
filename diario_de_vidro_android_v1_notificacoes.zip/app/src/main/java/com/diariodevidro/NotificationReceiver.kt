package com.diariodevidro

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        NotificationHelper.show(
            context,
            NotificationScheduler.id(intent),
            NotificationScheduler.title(intent),
            NotificationScheduler.message(intent)
        )
    }
}
