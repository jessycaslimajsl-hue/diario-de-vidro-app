package com.diariodevidro

import android.app.*
import android.content.*
import android.os.Build
import androidx.core.app.NotificationCompat

object NotificationHelper {
    const val CHANNEL_ID = "diario_de_vidro_lembretes"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Lembretes do Diário de Vidro",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Lembretes de peso, tratamento, ciclo e rotina."
            }
            context.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    fun show(context: Context, id: Int, title: String, message: String) {
        createChannel(context)
        val intent = context.packageManager
            .getLaunchIntentForPackage(context.packageName)
        val pendingIntent = intent?.let {
            PendingIntent.getActivity(
                context, id, it,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(com.diariodevidro.R.drawable.ic_diario_vidro)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        if (pendingIntent != null) builder.setContentIntent(pendingIntent)

        context.getSystemService(NotificationManager::class.java)
            .notify(id, builder.build())
    }
}
