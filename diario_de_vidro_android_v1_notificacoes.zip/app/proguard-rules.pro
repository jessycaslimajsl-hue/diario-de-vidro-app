# Diário de Vidro — regras adicionais futuras
