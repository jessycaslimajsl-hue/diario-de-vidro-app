# Diário de Vidro — Android V1

Primeira versão Android baseada no protótipo web V6.

Inclui:
- planejamento semanal
- substituição individual de ingredientes
- quantidades de referência
- lista de compras automática
- acompanhamento de peso
- cardápio
- calendário
- evolução
- tratamento e ciclo, conforme o protótipo

A aplicação funciona offline para as funções existentes no HTML e mantém os dados via armazenamento local do WebView.

Para gerar o APK, abra este projeto no Android Studio e execute a tarefa assembleDebug.
